#!/usr/bin/python

print ("Content-type: text/html")
print()

import mysql.connector
   
import cgi
formData = cgi.FieldStorage()

# import and enable CGI traceback - so errors will show in the browser
import cgitb
cgitb.enable()

VERBOSE = True
def verboseprint(st):
  if VERBOSE:
    print(st)
    
typeOfCount = formData.getvalue("typeOfCount")

database = mysql.connector.connect(
  host="localhost",
  user="abiddata",
  passwd="abiddata688",
  database = "g5"
)

#get count of donor id from the donor table for benefactors and count of donation id for each event  
mycursor = database.cursor()
if typeOfCount == "Total":
  sql = f"SELECT COUNT(Donor_ID) FROM Donor"
  #verboseprint(f"Insert query is {sql}")
  mycursor.execute(sql)
  myresult = mycursor.fetchone()
  if myresult is not None:
    print(f"""
                Our Benfactors: <span class="clsTotal">{myresult[0]}</span>
    """)
if typeOfCount == "Spring":
  sql = f"SELECT COUNT(Blood_Donation.Donation_ID) FROM Donor JOIN Blood_Donation ON ( Donor.Donor_ID = Blood_Donation.Donor_ID ) WHERE Blood_Donation.Date_of_donation = \'2020-01-01\'"
  #verboseprint(f"Insert query is {sql}")
  mycursor.execute(sql)
  myresult1 = mycursor.fetchone()
  if myresult1 is not None:
    print(f"""
                <p>Registerd Donors <span>{myresult1[0]}</span></p>
    """)
if typeOfCount == "Summer":
  sql = f"SELECT COUNT(Blood_Donation.Donation_ID) FROM Donor JOIN Blood_Donation ON ( Donor.Donor_ID = Blood_Donation.Donor_ID ) WHERE Blood_Donation.Date_of_donation = \'2020-04-01\'"
  #verboseprint(f"Insert query is {sql}")
  mycursor.execute(sql)
  myresult1 = mycursor.fetchone()
  if myresult1 is not None:
    print(f"""
                <p>Registerd Donors <span>{myresult1[0]}</span></p>
    """)
if typeOfCount == "Fall":
  sql = f"SELECT COUNT(Blood_Donation.Donation_ID) FROM Donor JOIN Blood_Donation ON ( Donor.Donor_ID = Blood_Donation.Donor_ID ) WHERE Blood_Donation.Date_of_donation = \'2020-06-01\'"
  #verboseprint(f"Insert query is {sql}")
  mycursor.execute(sql)
  myresult1 = mycursor.fetchone()
  if myresult1 is not None:
    print(f"""
                <p>Registerd Donors <span>{myresult1[0]}</span></p>
    """)
if typeOfCount == "Winter":
  sql = f"SELECT COUNT(Blood_Donation.Donation_ID) FROM Donor JOIN Blood_Donation ON ( Donor.Donor_ID = Blood_Donation.Donor_ID ) WHERE Blood_Donation.Date_of_donation = \'2020-10-01\'"
  #verboseprint(f"Insert query is {sql}")
  mycursor.execute(sql)
  myresult1 = mycursor.fetchone()
  if myresult1 is not None:
    print(f"""
                <p>Registerd Donors <span>{myresult1[0]}</span></p>
    """)
