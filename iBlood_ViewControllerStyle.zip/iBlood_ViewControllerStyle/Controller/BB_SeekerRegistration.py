#!/usr/bin/python

print ("Content-type: text/html\n")

# file Add seeker, update seeker- read information from seeker.html and update database

# Create the HTML page title and header for the output
print("""<html xmlns = "http://www.w3.org/1999/xhtml">
   <head>
      <title>Request Registration</title>
      <link href="../Style/BB_Overall.css" rel="stylesheet" type="text/css">
   </head>
  
   <body style = \"font-family: arial,sans-serif\">""")

# use the Python MySQL connector package
import mysql.connector

# Get the data from the form (through HTTP POST using the Common Gateway Interface)
import cgi
formData = cgi.FieldStorage()

# import and enable CGI traceback - so errors will show in the browser
import cgitb
cgitb.enable()

# For debugging purposes, define the function verboseprint.   It will print out a lot of stuff only if VERBOSE is set to true
VERBOSE = True
def verboseprint(st):
  if VERBOSE:
    print(st)

# Assign Python variables for each of the form inputs
# In this case, we are using the same name for each Python variable that we use for the name of the input element
# We do not have to do this.   We could use different variable names
Seeker_FirstName = formData.getvalue("Seeker_FirstName")
Seeker_LastName = formData.getvalue("Seeker_LastName")  
Seeker_address = formData.getvalue("Seeker_address")
Seeker_Ph = formData.getvalue("Seeker_Ph")
Seeker_email = formData.getvalue("Seekeremail")
Requested_blood_type = formData.getvalue("Requested_blood_type")
Requested_quantity = formData.getvalue("Requested_quantity")
Requested_by_Date = formData.getvalue("Requested_by_Date")

# Open the g5 database using the same user credentials
database = mysql.connector.connect(
  host="localhost",
  user="neviya19",
  passwd="neviya19428",
  database = "g5"
)

##print(f"""<p> Thank you for sharing your information Mr./Miss {Seeker_FirstName}.
##         Your request for {Requested_blood_type} blood has been added to our database.
##      </p>
##      <strong>The following information has been saved 
##          in our database:</strong><br />
##   
##      <table width="639" height="66" border = "0" cellpadding = "0" cellspacing = "10">
##         <tr>
##            <td width="73" bgcolor = "#ffffaa">First Name </td>
##            <td width="72" bgcolor = "#ffffbb">Last Name</td>
##            <td width="160" bgcolor = "#ffffbb">Address</td>
##            <td width="160" bgcolor = "#ffffbb">Phone Number</td>
##            <td width="160" bgcolor = "#ffffbb">email</td>
##            <td width="160" bgcolor = "#ffffbb">Blood type</td>
##            <td width="160" bgcolor = "#ffffbb">Requested quantity</td>
##            <td width="160" bgcolor = "#ffffbb">Requested by date</td>
##         </tr>""")
###Now print out each form field's value (helpful for debugging)
##print(f"<td>{Seeker_FirstName}</td>")
##print(f"<td>{Seeker_LastName}</td>")
##print(f"<td>{Seeker_address}</td>")
##print(f"<td>{Seeker_Ph}</td>")
##print(f"<td>{Seeker_email}</td>")
##print(f"<td>{Requested_blood_type}</td>")
##print(f"<td>{Requested_quantity}</td>")
##print(f"<td>{Requested_by_Date}</td>")
##print("""</tr>
##      </table>
##      <br /><br /><br />""")

# Now we start running database queries

mycursor = database.cursor()
# Start by checking if the Seeker_name is already in the database
# If not, add it to seeker table
myresult = mycursor.fetchone()
sql = f"INSERT INTO Seeker (Seeker_FirstName, Seeker_LastName, Seeker_address, Seeker_email, Seeker_Ph)"\
  + f"VALUES ( \'{Seeker_FirstName}\' , \'{Seeker_LastName}\' , \'{Seeker_address}\' , \'{Seeker_email}\', \'{Seeker_Ph}\')"
#verboseprint(f"Insert query is {sql}")
#verboseprint("<br>")
mycursor.execute(sql)
database.commit()
Seeker_ID = mycursor.lastrowid
#verboseprint(f"Seeker id is {Seeker_ID}")
#verboseprint("<br>")

#Assigning Admin to handle seeker request 
sql = f"SELECT Admin_ID FROM  BloodDrive_Admin ORDER BY RAND() LIMIT 1"
mycursor.execute(sql)
myresult = mycursor.fetchone()
Admin_ID = myresult[0]

sql = f"INSERT INTO Seeker_Request (Requested_by_Date, Requested_blood_type, Requested_quantity, Seeker_ID, Admin_ID)"\
  + f"VALUES ( \'{Requested_by_Date}\' , \'{Requested_blood_type}\' , \'{Requested_quantity}\' , \'{Seeker_ID}\', \'{Admin_ID}\')"
#verboseprint(f"Insert query is {sql}")
#verboseprint("<br>")
mycursor.execute(sql)
database.commit()
Request_ID = mycursor.lastrowid
#verboseprint(f"Seeker id is {Request_ID}")
#verboseprint("<br>")

print(f"""
  <div style="
    display: flex;
    justify-content: space-around;">
  <section class="card2">
    <div style=\"text-align:center\"><img src=\"../Assets for project/Blood_Types/BloodBag.png\" alt="image of Blood bag" style=\"width:20%;\"/></div>

    <div style=\"text-align:center\">
      <p> Thank you </p>
      <h3>{Seeker_FirstName} {Seeker_LastName}</h3>
      <p>We have recieved your request for {Requested_blood_type} blood.</p>
      <p>We will get in touch with you shortly.</p>
      <p>In case of emergency <br> Call us at (240)-333-3333 </p>
      <p><a href=\"http://abiddata.psjconsulting.com/Team5/View/BB_HomePage.html\">Return to the Home Page</a> </p>
    </div>
  </section>
  </div>
""")
  
print("</body></html>")

