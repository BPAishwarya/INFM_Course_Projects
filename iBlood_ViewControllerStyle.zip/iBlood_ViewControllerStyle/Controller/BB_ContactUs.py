#!/usr/bin/python

#print ("Content-type: text/html\n")

# file BB_ContactUs.py - read information from BB_HomePage.html and update database

# Create the HTML page title and header for the output
##print("""<html xmlns = "http://www.w3.org/1999/xhtml">
##   <head>
##      <title>Contact Us and Update Database</title>
##   </head>
##
##   <body style = \"font-family: arial,sans-serif\">""")

# use the Python MySQL connector package
import mysql.connector

# Get the data from the form (through HTTP POST using the Common Gateway Interface)
import cgi
formData = cgi.FieldStorage()

# import and enable CGI traceback - so errors will show in the browser
import cgitb
cgitb.enable()

# For debugging purposes, define the function verboseprint.   It will print out a lot of stuff only if VERBOSE is set to true
VERBOSE = True
def verboseprint(st):
  if VERBOSE:
    print(st)

# Assign Python variables for each of the seven form inputs
# In this case, we are using the same name for each Python variable that we use for the name of the input element
# We do not have to do this.   We could use different variable names
Contact_Name = formData.getvalue("Name")
Contact_Ph = formData.getvalue("Ph")
Contact_Email = formData.getvalue("email")  
Contact_Desc = formData.getvalue("Desc")  

# Open the g5 database
database = mysql.connector.connect(
  host="localhost",
  user="neviya19",
  passwd="neviya19428",
  database = "g5"
)

# print(f"""
#     <strong>The following information is being saved 
#         in our database:</strong><br />
 
#       <table width=\"639\" height=\"66\" border = \"0\" cellpadding = \"0\" cellspacing = \"10\">
#          <tr>
#             <td width=\"90\" bgcolor = \"#ffffaa\">Donor Name</td>
#             <td width=\"72\" bgcolor = \"#ffffbb\">Phone Number</td>
#             <td width=\"80\" bgcolor = \"#ffffbb\">Email</td>
#             <td width=\"80\" bgcolor = \"#ffffbb\">Description</td>
            
#          </tr>

#          <tr>
# 		   <td>{Contact_Name} </td>
# 		   <td>{Contact_Ph}</td>
#            <td>{Contact_Email}</td>
# 		   <td>{Contact_Desc}</td>
#          </tr>
#       </table>
   
#       <br /><br /><br />""")

mycursor = database.cursor()
#Assigning Admin to handle seeker request 
sql = f"SELECT Admin_ID FROM  BloodDrive_Admin ORDER BY RAND() LIMIT 1"
mycursor.execute(sql)
myresult = mycursor.fetchone()
Admin_ID = myresult[0]


sql = f"INSERT INTO Contact_Us (Contact_Name, Contact_Ph, Contact_Email, Contact_Desc, Admin_ID)"\
  + f"VALUES ( \'{Contact_Name}\' , \'{Contact_Ph}\' , \'{Contact_Email}\' , \'{Contact_Desc}\', \'{Admin_ID}\')"
#verboseprint(f"Insert query is {sql}")
#verboseprint("<br>")
mycursor.execute(sql)
database.commit()
Contact_ID = mycursor.lastrowid


print(f"""
  
      <p> Thank you for contacting us 
      <b>{Contact_Name}</b> </p>
      <p>We have recieved your message
      We will get in touch with you shortly.</p>
      
   
""")
  
#print("</body></html>")

