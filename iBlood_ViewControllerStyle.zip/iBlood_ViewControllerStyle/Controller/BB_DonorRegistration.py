#!/usr/bin/python

print ("Content-type: text/html\n")

# file BB_DonorRegistration.py - read information from BB_DonorRegistration.html and update database

#Create the HTML page title and header for the output
print("""<html xmlns = "http://www.w3.org/1999/xhtml">
   <head>
      <title>Donor Registration Form Validation and Database Update</title>
      <link href="../Style/BB_Overall.css" rel="stylesheet" type="text/css">
   </head>
  
   <body style = \"font-family: arial,sans-serif\">""")

# use the Python MySQL connector package
import mysql.connector

# Get the data from the form (through HTTP POST using the Common Gateway Interface)
import cgi
formData = cgi.FieldStorage()

# import and enable CGI traceback - so errors will show in the browser
import cgitb
cgitb.enable()

# For debugging purposes, define the function verboseprint.   It will print out a lot of stuff only if VERBOSE is set to true
VERBOSE = True
def verboseprint(st):
  if VERBOSE:
    print(st)

# Assign Python variables for each of the seven form inputs
# In this case, we are using the same name for each Python variable that we use for the name of the input element
# We do not have to do this.   We could use different variable names
Donor_FirstName = formData.getvalue("Donor_FirstName")
Donor_LastName = formData.getvalue("Donor_LastName")
Donor_Ph = formData.getvalue("Donor_Ph")
Donor_email = formData.getvalue("Donor_email")  
Donor_address = formData.getvalue("Donor_address")  
Donor_age = formData.getvalue("Donor_age")
Blood_Type = formData.getvalue("Blood_Type") 
Date_of_donation = formData.getvalue("Date_of_donation") 

# Open the g5 database
database = mysql.connector.connect(
  host="localhost",
  user="neviya19",
  passwd="neviya19428",
  database = "g5"
)

##print(f"""
##    <strong>The following information is being saved 
##        in our database:</strong><br />
## 
##      <table width=\"639\" height=\"66\" border = \"0\" cellpadding = \"0\" cellspacing = \"10\">
##         <tr>
##            <td width=\"90\" bgcolor = \"#ffffaa\">Donor Name</td>
##            <td width=\"72\" bgcolor = \"#ffffbb\">Phone Number</td>
##            <td width=\"80\" bgcolor = \"#ffffbb\">Email</td>
##            <td width=\"80\" bgcolor = \"#ffffbb\">Address</td>
##            <td width=\"80\" bgcolor = \"#ffffbb\">Age</td>
##			<td width=\"80\" bgcolor = \"#ffffbb\">Blood Type</td>
##			<td width=\"80\" bgcolor = \"#ffffbb\">Date of Donation</td>
##         </tr>
##
##         <tr>
##		   <td>{Donor_FirstName} {Donor_LastName}</td>
##		   <td>{Donor_Ph}</td>
##           <td>{Donor_email}</td>
##		   <td>{Donor_address}</td>
##		   <td>{Donor_age}</td>
##		   <td>{Blood_Type}</td>
##		   <td>{Date_of_donation}</td>
##         </tr>
##      </table>
##   
##      <br /><br /><br />""")
	  
# Start by checking if the donor is already in the database - if yes, update it,
# If not, add the donor and set Donor_ID to add to donor table
mycursor = database.cursor()
  # This code doesn't add a new Admin 
sql = f"SELECT Admin_ID FROM  BloodDrive_Admin ORDER BY RAND() LIMIT 1"
mycursor.execute(sql)
myresult = mycursor.fetchone()
Admin_ID = myresult[0]
sql = f"SELECT Donor_ID FROM Donor WHERE Donor_FirstName = \'{Donor_FirstName}\' AND Donor_LastName = \'{Donor_LastName}\'"
mycursor.execute(sql)
myresult = mycursor.fetchone()
  
# If the donor isn't in the database, add it
if myresult is None:
  sql = f"INSERT INTO Donor (Donor_FirstName,Donor_LastName,Donor_Ph,Donor_email,Donor_address,Donor_age,Blood_Type,Admin_ID)"\
  + f"VALUES ( \'{Donor_FirstName}\' , \'{Donor_LastName}\' , \'{Donor_Ph}\', \'{Donor_email}\', \'{Donor_address}\', \'{Donor_age}\', \'{Blood_Type}\', \'{Admin_ID}\')"
  mycursor.execute(sql)
  database.commit()
  Donor_ID = mycursor.lastrowid
  
  #verboseprint(f"New Donor ID is {Donor_ID}")
  #verboseprint(f"{Donor_FirstName}{Donor_LastName} has been registered successfully<br>")
  #verboseprint("<br>")
# else update the donor info
else:
  Donor_ID = myresult[0]
  sql = f"UPDATE Donor SET Donor_Ph = \'{Donor_Ph}\', Donor_email = \'{Donor_email}\',Donor_address = \'{Donor_address}\',Donor_age = \'{Donor_age}\' WHERE Donor_ID = \'{Donor_ID}\'"
  #verboseprint(f"Donor {Donor_FirstName} {Donor_LastName} already registered. information updated.<br>")
  mycursor.execute(sql)
  database.commit()

#check if the donor already exists  
sql = f"SELECT Donation_ID FROM Blood_Donation WHERE Donor_ID = \'{Donor_ID}\' AND Date_of_donation = \'{Date_of_donation}\'"
mycursor.execute(sql)
myresult = mycursor.fetchone()
# If the donor isn't in the database for the specific event, add it
if myresult is None:
  sql = f"INSERT INTO Blood_Donation (Donor_ID,Admin_ID,Date_of_donation)"\
  + f"VALUES ( \'{Donor_ID}\' , \'{Admin_ID}\' , \'{Date_of_donation}\')"
  mycursor.execute(sql)
  database.commit()
  print(f"""
  <div style="
    display: flex;
    justify-content: space-around;">
  <section class="card2">
    <div><img src=\"../Assets for project/Emergency.png\" alt="image for emergency responders" style=\"width:100%; height=20%\"/></div>

    <div style=\"text-align:center\">
      <p> and now you are our hero!</p>
      <h3>{Donor_FirstName} {Donor_LastName}</h3>
      <p>Thank you for taking the first step</p>
      <p>to save someone's life!</p>
      <p>Further instructions will be communicated to you <br> via the email
      that you used to register. </p>
      <p><a href=\"http://abiddata.psjconsulting.com/Team5/View/BB_HomePage.html\">Return to the Home Page</a> </p>
    </div>
  </section>
  </div>
  """)
  
  #verboseprint(f"Donor {Donor_FirstName} {Donor_LastName} has registered for the donation successfully.<br>")
  #verboseprint("<br>")
# else dont change database and display alreadry registered message
else:
  print(f"""
  <div style="
    display: flex;
    justify-content: space-around;">
  <section class="card2">
    <div><img src=\"../Assets for project/Emergency.png\" alt="image for emergency responders" style=\"width:100%; height=20%\"/></div>

    <div style=\"text-align:center\">
      <p> You are already registered for this event!</p>
      <p> Thank you once again!</p>
      <p><a href=\"http://abiddata.psjconsulting.com/Team5/View/BB_HomePage.html\">Return to the Home Page</a> </p>
    </div>
  </section>
  </div>
  """)

print("</body></html>")
